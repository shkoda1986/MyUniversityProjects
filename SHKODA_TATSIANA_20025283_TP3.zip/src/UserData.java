
/***
 * 
 * @author tatsiana shkoda
 *  class pour garder le login et mot de pass
 */
public class UserData {
	
	    public static String login="shkodata";
	    public static String passwd="zWU2T7NcfN+g_M";

}
